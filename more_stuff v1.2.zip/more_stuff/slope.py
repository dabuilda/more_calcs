def slope(cor1, cor2):
    cor1 = cor1.split(",")
    cor2 = cor2.split(",")
    num1, num2 = cor1
    num3, num4 = cor2
    final_cor1 = int(num4) - int(num2)
    final_cor2 = int(num3) - int(num1)
    ans = final_cor1 / final_cor2
    return ans


def slope_return_y(yslope, yint, x):
    y = yslope * x + yint
    return y


def slope_return_x(xslope, yint, y):
    x = (y - yint) / xslope
    return x

