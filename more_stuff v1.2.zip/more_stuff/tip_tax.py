def sales_tax_total(rate, cost):
    total = cost * rate
    return total


def sales_tax_rate(total, cost):
    rate = total / cost
    return rate


def sales_tax_cost(total, rate):
    cost = total / rate
    return cost


def find_tip(cost, tip_rate_in_decimal):
    tip = cost * (1 + tip_rate_in_decimal)
    return tip


def tip_tax_final_cost(cost, tip_rate_in_decimal, tax_rate):
    tip = cost * (1 + tip_rate_in_decimal)
    tax = cost * tax_rate
    total = tip + tax
    return total

