def mean_avg(dataset_mean):
    dataset_len = len(dataset_mean)
    total = sum(dataset_mean) / dataset_len
    return total


def mode_avg(dataset_mode):
    counter = 0
    total = dataset_mode[0]

    for num in dataset_mode:
        current_num = dataset_mode.count(num)
        if current_num > counter:
            counter = current_num
            total = num

    return total


def range_avg(dataset_range):
    max_range = max(dataset_range)
    min_range = min(dataset_range)
    total = max_range - min_range
    return total


def median_avg(dataset_median):
    n = len(dataset_median)
    dataset_median.sort()

    if n % 2 == 0:
        median1 = dataset_median[n // 2]
        median2 = dataset_median[n // 2 - 1]
        median = (median1 + median2) / 2
    else:
        median = dataset_median[n // 2]

    return median
