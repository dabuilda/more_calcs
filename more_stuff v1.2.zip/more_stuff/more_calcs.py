def opposite(opposite_input):
    opposite_output = -1 * opposite_input
    return opposite_output


