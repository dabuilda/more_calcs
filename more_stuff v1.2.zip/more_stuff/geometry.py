def circle_area(radius):
    area_circle = (radius * radius) * 3.14159265359
    return area_circle


def circle_circumference(diameter):
    circumference_circle = 3.14159265359 * diameter
    return circumference_circle


def square_area(square_area_one_side):
    area_square = square_area_one_side * square_area_one_side
    return area_square


def square_perimeter(square_perimeter_one_side):
    perimeter_square = square_perimeter_one_side * 4
    return perimeter_square


def rectangle_area(side1, side2):
    area_rectangle = side1 * side2
    return area_rectangle


def rectangle_perimeter(side1, side2):
    perimeter_rectangle = (side1 * 2) + (side2 * 2)
    return perimeter_rectangle


def triangle_area(triangle_base, triangle_height):
    area = 1/2 * (triangle_base * triangle_height)
    return area


def find_missing_angle_triangle(angle_one, angle_two):
    missing_angle = 180 - (angle_one + angle_two)
    return missing_angle


def trapezoid_area(top_parallel_side, bottom_parallel_side, height):
    area_trapezoid = (top_parallel_side + bottom_parallel_side) / 2 * height
    return area_trapezoid


def volume(vol_length, vol_width, vol_height):
    final_volume = vol_height * vol_length * vol_width
    return final_volume

